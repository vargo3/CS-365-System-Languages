//Jacob Vargo

#include "Queue.h"
#include <list>
using namespace std;

class ArrayQueue : public Queue{
	public:
		void add(int value) { queue.push_back(value); }
		int remove() { 
			int rv = queue.front();
			queue.pop_front();
			return rv;
		}
		bool isEmpty() { return queue.empty(); }
	protected:
		list<int> queue;
};
