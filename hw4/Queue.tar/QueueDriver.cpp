//Jacob Vargo

#include <stdio.h>
#include "Queue.h"
#include "ArrayQueue.cpp"

int main(int argc, char **argv){
	Queue *q = new ArrayQueue;
	q->add(3);
	q->add(10);
	q->add(5);
	for (int i = 0; i < 2; i++) printf("%d\n", q->remove());
	q->add(6);
	q->add(9);
	q->add(12);
	while(!q->isEmpty()) printf("%d\n", q->remove());
}
