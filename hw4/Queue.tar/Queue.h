//Jacob Vargo

//prevents this file from being included multiple times within the same file
#ifndef QUEUE_H
#define QUEUE_H

class Queue{
	public:
		virtual void add(int value) = 0;
		virtual int remove() = 0;
		virtual bool isEmpty() = 0;
};

#endif
